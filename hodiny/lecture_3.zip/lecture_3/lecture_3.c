

#include "pico/stdlib.h"
#include <stdio.h>
#include "hardware/adc.h"
#include "hardware/pwm.h"
#include "hardware/gpio.h"
// TODO: Define your pin configuration
// Choose appropriate pins for:
// - LED output (must support PWM)
// - Potentiometer input (must support ADC - GPIO26-29)
// Define appropriate PWM wrap value for brightness control

uint16_t map_value(uint16_t value, uint16_t in_min, uint16_t in_max,
                   uint16_t out_min, uint16_t out_max);

// Timing definitions (in milliseconds)
#define DOT_DURATION 200
#define DASH_DURATION (DOT_DURATION * 3)
#define SYMBOL_SPACE (DOT_DURATION)
#define LETTER_SPACE (DOT_DURATION * 3)
#define WORD_SPACE (DOT_DURATION * 7)
#define MAX_INPUT 100
#define PIN_LED 6

// Morse code lookup table (DO NOT MODIFY)
const char *MORSE_CODE[] = {
    ".-",   // A
    "-...", // B
    "-.-.", // C
    "-..",  // D
    ".",    // E
    "..-.", // F
    "--.",  // G
    "....", // H
    "..",   // I
    ".---", // J
    "-.-",  // K
    ".-..", // L
    "--",   // M
    "-.",   // N
    "---",  // O
    ".--.", // P
    "--.-", // Q
    ".-.",  // R
    "...",  // S
    "-",    // T
    "..-",  // U
    "...-", // V
    ".--",  // W
    "-..-", // X
    "-.--", // Y
    "--.."  // Z
};

// Function declarations
void init_pwm(void);
void init_adc(void);
uint16_t read_brightness(void);
int set_led_brightness();
void display_dot(void);
void display_dash(void);
void display_character(char c);
bool read_line(char *buffer, int max_length);
void clear_input_buffer(void);

int main()
{
    stdio_init_all();
    sleep_ms(2000); // Wait for USB serial to initialize

    init_pwm();
    init_adc();

    printf("Morse Code LED Controller\n");
    printf("Use potentiometer to control LED brightness\n\n");

    char input[MAX_INPUT];

    while (true)
    {
        printf("Enter text to convert to Morse code (max %d chars): ", MAX_INPUT - 1);

        if (read_line(input, MAX_INPUT))
        {
            printf("Converting: %s\n", input);

            for (int i = 0; input[i] != '\0'; i++)
            {
                display_character(input[i]);
            }

            printf("\nConversion complete!\n\n");
        }

        clear_input_buffer(); // Clear any remaining input
        sleep_ms(100);
    }

    return 0;
}

// TODO: Implement PWM initialization
// Configure LED pin for PWM output with appropriate frequency
void init_pwm(void)
{
    gpio_set_function(6, GPIO_FUNC_PWM);
    uint slice_num = pwm_gpio_to_slice_num(6);
    uint channel = pwm_gpio_to_channel(6);

    pwm_config config = pwm_get_default_config();
    pwm_config_set_clkdiv(&config, 125);
    pwm_config_set_wrap(&config, 1000);

    pwm_init(slice_num, &config, true);
}

// TODO: Implement ADC initialization
// Configure ADC for potentiometer reading
void init_adc(void)
{

    adc_init();
    adc_gpio_init(28);
    adc_select_input(0);
}

// TODO: Implement potentiometer reading
// Read ADC value and scale it to PWM range
uint16_t read_brightness(void)
{

    uint16_t in_min = 0;
    uint16_t in_max = 4095;
    uint16_t out_min = 0;
    uint16_t out_max = 1000;

    uint16_t value = adc_read();

    uint16_t hodnota = map_value(value, in_min, in_max, out_min, out_max);

    return hodnota;
}

// TODO: Implement LED brightness control
// Set LED brightness using PWM
int set_led_brightness()
{
    int bomboclat = read_brightness();

    pwm_set_chan_level(pwm_gpio_to_slice_num(6), PWM_CHAN_A, bomboclat);

    return bomboclat;
}

// TODO: Implement Morse code dot
void display_dot(void)
{
    int brightness = set_led_brightness();

    pwm_set_gpio_level(PIN_LED, brightness);
    sleep_ms(DOT_DURATION);
    pwm_set_gpio_level(PIN_LED, 0);
    sleep_ms(SYMBOL_SPACE);
}

// TODO: Implement Morse code dash
void display_dash(void)
{
    int brightness = set_led_brightness();

    pwm_set_gpio_level(PIN_LED, brightness);
    sleep_ms(DASH_DURATION);
    pwm_set_gpio_level(PIN_LED, 0);
    sleep_ms(SYMBOL_SPACE);
}

// TODO: Implement character display function
// Handle uppercase letters, lowercase letters, and spaces
void display_character(char c)
{

    // Your implementation here:
    // 1. Handle spaces (use WORD_SPACE)
    // 2. Convert lowercase letters to uppercase
    // 3. Verify character is a valid letter (A-Z)
    // 4. Get morse code pattern from MORSE_CODE array
    const char *pattern = MORSE_CODE[c - 'A'];
    printf("%s ", pattern); // Sample code to print morse code pattern
    // 5. Display pattern using display_dot and display_dash
    // 6. Add appropriate letter space after each character
}

// Function to clear input buffer (DO NOT MODIFY)
void clear_input_buffer(void)
{
    while (getchar_timeout_us(0) != PICO_ERROR_TIMEOUT)
    {
        // Clear any remaining characters
    }
}

// Function to read input (DO NOT MODIFY)
bool read_line(char *buffer, int max_length)
{
    int index = 0;
    int c;

    while (index < max_length - 1)
    {
        c = getchar_timeout_us(50000);

        if (c == PICO_ERROR_TIMEOUT)
        {
            if (index == 0)
                continue;
            break;
        }

        if (c == '\r' || c == '\n')
        {
            if (index > 0)
                break;
            continue;
        }

        putchar(c);
        buffer[index++] = (char)c;
    }

    buffer[index] = '\0';
    putchar('\n');
    return index > 0;
}